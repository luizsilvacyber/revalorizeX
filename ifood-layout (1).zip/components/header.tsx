import { MapPin, Search, Leaf } from "lucide-react"
import { Input } from "@/components/ui/input"

export function Header() {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50 border-b border-green-100">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <Leaf className="w-8 h-8 text-green-600" />
              <h1 className="text-2xl font-bold text-green-700">ReValorize</h1>
              <span className="text-lg">♻️</span>
            </div>
          </div>
          <div className="flex items-center text-gray-600 text-sm">
            <MapPin className="w-4 h-4 mr-1 text-green-600" />
            <span>Entregar em</span>
            <span className="font-semibold ml-1">Rua Solidária, 123</span>
          </div>
        </div>

        <div className="text-center mb-3">
          <p className="text-green-700 font-medium italic">"O que não serve para uns, vale muito para outros."</p>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-green-500 w-4 h-4" />
          <Input
            placeholder="Busque produtos sustentáveis..."
            className="pl-10 h-12 bg-green-50 border-green-200 rounded-lg focus:border-green-400"
          />
        </div>
      </div>
    </header>
  )
}
