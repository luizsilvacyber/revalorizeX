import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { User, MapPin, Phone, Mail, Award, Heart, Settings, HelpCircle, LogOut } from "lucide-react"

export function ProfileScreen() {
  return (
    <div className="p-4 space-y-6">
      <div className="max-w-4xl mx-auto">
        {/* Profile Header */}
        <Card className="bg-gradient-to-r from-green-600 to-green-700 text-white">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                <User className="w-10 h-10" />
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold">Maria Silva</h1>
                <p className="text-green-100">Membro desde Janeiro 2024</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge className="bg-white/20 text-white border-white/30">
                    <Award className="w-3 h-3 mr-1" />
                    Usuário Verificado
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Impact Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Heart className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-800">47</p>
              <p className="text-sm text-blue-600">Produtos adquiridos</p>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4 text-center">
              <Award className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-800">R$ 340</p>
              <p className="text-sm text-green-600">Economizado total</p>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl mb-2">🌱</div>
              <p className="text-2xl font-bold text-amber-800">23kg</p>
              <p className="text-sm text-amber-600">CO₂ evitado</p>
            </CardContent>
          </Card>
        </div>

        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Pessoais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-3">
              <Mail className="w-5 h-5 text-gray-500" />
              <div>
                <p className="font-medium">Email</p>
                <p className="text-gray-600">maria.silva@email.com</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Phone className="w-5 h-5 text-gray-500" />
              <div>
                <p className="font-medium">Telefone</p>
                <p className="text-gray-600">(11) 99999-9999</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <MapPin className="w-5 h-5 text-gray-500" />
              <div>
                <p className="font-medium">Endereço</p>
                <p className="text-gray-600">Rua das Flores, 123 - São Paulo, SP</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Social Verification */}
        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="text-green-700">Verificação Social</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Status CadÚnico</p>
                <p className="text-sm text-green-600">Verificado ✓</p>
                <p className="text-xs text-gray-500 mt-1">Última atualização: 15/12/2024</p>
              </div>
              <Badge className="bg-green-100 text-green-700">Ativo</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Menu Options */}
        <div className="space-y-3">
          <Button variant="ghost" className="w-full justify-start h-12">
            <Settings className="w-5 h-5 mr-3" />
            Configurações
          </Button>

          <Button variant="ghost" className="w-full justify-start h-12">
            <HelpCircle className="w-5 h-5 mr-3" />
            Ajuda e Suporte
          </Button>

          <Button variant="ghost" className="w-full justify-start h-12 text-red-600 hover:text-red-700 hover:bg-red-50">
            <LogOut className="w-5 h-5 mr-3" />
            Sair
          </Button>
        </div>
      </div>
    </div>
  )
}
