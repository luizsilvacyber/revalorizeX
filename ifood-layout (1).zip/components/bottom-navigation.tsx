"use client"

import { Home, Package, Ticket, Truck, User } from "lucide-react"
import type { Screen } from "@/app/page"

interface BottomNavigationProps {
  currentScreen: Screen
  onNavigate: (screen: Screen) => void
}

export function BottomNavigation({ currentScreen, onNavigate }: BottomNavigationProps) {
  const navItems = [
    { id: "home" as Screen, icon: Home, label: "Início" },
    { id: "products" as Screen, icon: Package, label: "Produtos" },
    { id: "coupons" as Screen, icon: Ticket, label: "Cupons" },
    { id: "delivery" as Screen, icon: Truck, label: "Entrega" },
    { id: "profile" as Screen, icon: User, label: "Perfil" },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = currentScreen === item.id

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center space-y-1 py-2 px-3 rounded-lg transition-colors ${
                isActive ? "text-green-600 bg-green-50" : "text-gray-500 hover:text-green-600"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
