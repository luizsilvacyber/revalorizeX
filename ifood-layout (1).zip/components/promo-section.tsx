import { Card } from "@/components/ui/card"

export function PromoSection() {
  return (
    <section className="px-4 py-6">
      <div className="max-w-7xl mx-auto">
        <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white p-6 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold mb-2">Entrega grátis</h2>
              <p className="text-red-100">Em pedidos acima de R$ 30</p>
            </div>
            <div className="text-4xl">🚚</div>
          </div>
        </Card>
      </div>
    </section>
  )
}
