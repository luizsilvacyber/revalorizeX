import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Ticket, Gift, Clock, TrendingUp } from "lucide-react"

export function CouponsScreen() {
  const availableCoupons = [
    {
      id: 1,
      title: "Entrega Grátis",
      description: "Para produtos até R$ 50",
      value: "R$ 8,00",
      expires: "30 dias",
      type: "delivery",
    },
    {
      id: 2,
      title: "Desconto Alimentos",
      description: "20% off em alimentos",
      value: "20%",
      expires: "15 dias",
      type: "food",
    },
    {
      id: 3,
      title: "Cupom Roupas",
      description: "R$ 10 off em roupas",
      value: "R$ 10,00",
      expires: "45 dias",
      type: "clothes",
    },
  ]

  const usedCoupons = [
    { id: 1, title: "Entrega Grátis", usedDate: "15/12/2024", savedAmount: "R$ 8,00" },
    { id: 2, title: "Desconto Móveis", usedDate: "10/12/2024", savedAmount: "R$ 25,00" },
    { id: 3, title: "Cupom Higiene", usedDate: "05/12/2024", savedAmount: "R$ 12,00" },
  ]

  return (
    <div className="p-4 space-y-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Meus Cupons</h1>
          <p className="text-gray-600">Economize mais com nossos cupons sociais</p>
        </div>

        {/* Balance Card */}
        <Card className="bg-gradient-to-r from-green-600 to-green-700 text-white mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold mb-1">Saldo Disponível</h2>
                <p className="text-3xl font-bold">R$ 38,00</p>
                <p className="text-green-100 text-sm">em cupons ativos</p>
              </div>
              <div className="text-4xl">🎟️</div>
            </div>
          </CardContent>
        </Card>

        {/* Impact Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-800">R$ 145,00</p>
              <p className="text-sm text-blue-600">Economizado este mês</p>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4 text-center">
              <Gift className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-800">12</p>
              <p className="text-sm text-green-600">Cupons utilizados</p>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-200">
            <CardContent className="p-4 text-center">
              <Ticket className="w-8 h-8 text-amber-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-amber-800">3</p>
              <p className="text-sm text-amber-600">Cupons ativos</p>
            </CardContent>
          </Card>
        </div>

        {/* Available Coupons */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Cupons Disponíveis</h2>
          <div className="space-y-3">
            {availableCoupons.map((coupon) => (
              <Card key={coupon.id} className="border-green-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <Ticket className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{coupon.title}</h3>
                        <p className="text-sm text-gray-600">{coupon.description}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            <Clock className="w-3 h-3 mr-1" />
                            {coupon.expires}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-green-600">{coupon.value}</p>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        Usar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Used Coupons History */}
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Histórico de Uso</h2>
          <div className="space-y-3">
            {usedCoupons.map((coupon) => (
              <Card key={coupon.id} className="bg-gray-50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                        <Ticket className="w-6 h-6 text-gray-500" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-700">{coupon.title}</h3>
                        <p className="text-sm text-gray-500">Usado em {coupon.usedDate}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-500">Economia</p>
                      <p className="font-bold text-green-600">{coupon.savedAmount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
