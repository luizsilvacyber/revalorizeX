import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp, Recycle, Users } from "lucide-react"

export function ImpactStats() {
  return (
    <section className="px-4">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Impacto da Comunidade</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4 text-center">
              <Recycle className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-800">2.847</p>
              <p className="text-sm text-green-600">Produtos reaproveitados</p>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-800">1.234</p>
              <p className="text-sm text-blue-600">Famílias beneficiadas</p>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 text-amber-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-amber-800">R$ 89.5k</p>
              <p className="text-sm text-amber-600">Economia gerada</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
