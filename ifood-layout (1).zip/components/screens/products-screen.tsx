import { FeaturedProducts } from "@/components/featured-products"
import { CategorySlider } from "@/components/category-slider"
import type { Product } from "@/app/page"

interface ProductsScreenProps {
  onProductSelect: (product: Product) => void
}

export function ProductsScreen({ onProductSelect }: ProductsScreenProps) {
  return (
    <div className="space-y-6">
      <CategorySlider />
      <FeaturedProducts onProductSelect={onProductSelect} />
    </div>
  )
}
