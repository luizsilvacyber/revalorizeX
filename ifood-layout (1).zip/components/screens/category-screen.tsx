"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, MapPin, Heart } from "lucide-react"
import type { Product } from "@/app/page"

const allProducts: Product[] = [
  // Alimentos
  {
    id: 1,
    name: "Cesta de Verduras Orgânicas",
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=300&h=200&fit=crop",
    price: "Grátis",
    category: "Alimentos",
    description: "Verduras frescas próximas do vencimento, perfeitas para consumo imediato",
    location: "Mercado Verde - 2km",
    condition: "Excelente",
    seller: "Mercado Verde",
    isFree: true,
  },
  {
    id: 2,
    name: "Frutas Variadas",
    image: "https://images.unsplash.com/photo-1619566636858-adf3ef46400b?w=300&h=200&fit=crop",
    price: "R$ 8,00",
    category: "Alimentos",
    description: "Mix de frutas frescas com pequenas imperfeições estéticas",
    location: "Feira Solidária - 1.5km",
    condition: "Bom",
    seller: "Feira Solidária",
    isFree: false,
  },
  {
    id: 3,
    name: "Pães Artesanais",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=300&h=200&fit=crop",
    price: "R$ 5,00",
    category: "Alimentos",
    description: "Pães frescos do dia anterior, ideais para torradas",
    location: "Padaria Esperança - 0.8km",
    condition: "Muito Bom",
    seller: "Padaria Esperança",
    isFree: false,
  },
  {
    id: 4,
    name: "Leite e Derivados",
    image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?w=300&h=200&fit=crop",
    price: "R$ 12,00",
    category: "Alimentos",
    description: "Leite, queijo e iogurte próximos do vencimento",
    location: "Laticínios Silva - 2.3km",
    condition: "Excelente",
    seller: "Laticínios Silva",
    isFree: false,
  },

  // Roupas
  {
    id: 5,
    name: "Jaqueta Jeans Feminina",
    image: "https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=300&h=200&fit=crop",
    price: "R$ 15,00",
    category: "Roupas",
    description: "Jaqueta jeans tamanho M, pouco usada, em ótimo estado",
    location: "Brechó Solidário - 1.5km",
    condition: "Muito Bom",
    seller: "Ana Silva",
    isFree: false,
  },
  {
    id: 6,
    name: "Camisetas Masculinas",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=200&fit=crop",
    price: "R$ 8,00",
    category: "Roupas",
    description: "Kit com 3 camisetas básicas tamanho G",
    location: "Doação Família Santos - 2km",
    condition: "Bom",
    seller: "Família Santos",
    isFree: false,
  },
  {
    id: 7,
    name: "Vestidos Infantis",
    image: "https://images.unsplash.com/photo-1596755389378-c31d21fd1273?w=300&h=200&fit=crop",
    price: "Grátis",
    category: "Roupas",
    description: "Vestidos infantis variados, tamanhos 4 a 8 anos",
    location: "ONG Criança Feliz - 1km",
    condition: "Muito Bom",
    seller: "ONG Criança Feliz",
    isFree: true,
  },
  {
    id: 8,
    name: "Sapatos Femininos",
    image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=300&h=200&fit=crop",
    price: "R$ 20,00",
    category: "Roupas",
    description: "Sapatos sociais femininos número 37, pouco uso",
    location: "Brechó Chique - 2.5km",
    condition: "Excelente",
    seller: "Brechó Chique",
    isFree: false,
  },

  // Móveis
  {
    id: 9,
    name: "Mesa de Jantar 4 Lugares",
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&h=200&fit=crop",
    price: "R$ 80,00",
    category: "Móveis",
    description: "Mesa de madeira com 4 cadeiras, pequenos riscos mas estrutura sólida",
    location: "Família Santos - 3km",
    condition: "Bom",
    seller: "João Santos",
    isFree: false,
  },
  {
    id: 10,
    name: "Sofá 2 Lugares",
    image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=300&h=200&fit=crop",
    price: "R$ 120,00",
    category: "Móveis",
    description: "Sofá confortável, tecido em bom estado",
    location: "Mudança Rápida - 2.8km",
    condition: "Muito Bom",
    seller: "Mudança Rápida",
    isFree: false,
  },
  {
    id: 11,
    name: "Estante de Livros",
    image: "https://images.unsplash.com/photo-1594736797933-d0401ba2fe65?w=300&h=200&fit=crop",
    price: "R$ 45,00",
    category: "Móveis",
    description: "Estante de madeira com 5 prateleiras",
    location: "Casa da Leitura - 1.8km",
    condition: "Bom",
    seller: "Casa da Leitura",
    isFree: false,
  },
  {
    id: 12,
    name: "Cama de Solteiro",
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=300&h=200&fit=crop",
    price: "Grátis",
    category: "Móveis",
    description: "Cama de solteiro com colchão, doação por mudança",
    location: "Família Oliveira - 4km",
    condition: "Bom",
    seller: "Família Oliveira",
    isFree: true,
  },

  // Eletrônicos
  {
    id: 13,
    name: "Smartphone Samsung J5",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=200&fit=crop",
    price: "R$ 120,00",
    category: "Eletrônicos",
    description: "Celular funcionando perfeitamente, apenas tela com pequenos riscos",
    location: "TechReuso - 2.5km",
    condition: "Bom",
    seller: "TechReuso",
    isFree: false,
  },
  {
    id: 14,
    name: "Notebook Dell",
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=200&fit=crop",
    price: "R$ 350,00",
    category: "Eletrônicos",
    description: "Notebook para estudos, funciona bem para tarefas básicas",
    location: "Informática Popular - 3.2km",
    condition: "Bom",
    seller: "Informática Popular",
    isFree: false,
  },
  {
    id: 15,
    name: "TV 32 polegadas",
    image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=200&fit=crop",
    price: "R$ 200,00",
    category: "Eletrônicos",
    description: "TV LED funcionando perfeitamente, com controle remoto",
    location: "Eletrônicos Baratos - 2km",
    condition: "Muito Bom",
    seller: "Eletrônicos Baratos",
    isFree: false,
  },
  {
    id: 16,
    name: "Fones de Ouvido",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=200&fit=crop",
    price: "R$ 25,00",
    category: "Eletrônicos",
    description: "Fones bluetooth em excelente estado",
    location: "Som & Cia - 1.5km",
    condition: "Excelente",
    seller: "Som & Cia",
    isFree: false,
  },

  // Livros
  {
    id: 17,
    name: "Livros Infantis Variados",
    image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=200&fit=crop",
    price: "R$ 5,00",
    category: "Livros",
    description: "Coleção de 10 livros infantis em bom estado",
    location: "Biblioteca Comunitária - 1.8km",
    condition: "Bom",
    seller: "Biblioteca Comunitária",
    isFree: false,
  },
  {
    id: 18,
    name: "Livros Didáticos",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=200&fit=crop",
    price: "R$ 15,00",
    category: "Livros",
    description: "Livros do ensino médio, várias matérias",
    location: "Escola Esperança - 2.2km",
    condition: "Bom",
    seller: "Escola Esperança",
    isFree: false,
  },

  // Brinquedos
  {
    id: 19,
    name: "Brinquedos Educativos",
    image: "https://images.unsplash.com/photo-1558877385-8c1b3b6e5b6a?w=300&h=200&fit=crop",
    price: "Grátis",
    category: "Brinquedos",
    description: "Kit de brinquedos educativos para crianças de 3 a 7 anos",
    location: "Creche Sorriso - 1.2km",
    condition: "Muito Bom",
    seller: "Creche Sorriso",
    isFree: true,
  },
  {
    id: 20,
    name: "Bonecas e Carrinhos",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300&h=200&fit=crop",
    price: "R$ 12,00",
    category: "Brinquedos",
    description: "Brinquedos variados em bom estado de conservação",
    location: "Família Costa - 2.5km",
    condition: "Bom",
    seller: "Família Costa",
    isFree: false,
  },

  // Utensílios
  {
    id: 21,
    name: "Kit Panelas",
    image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop",
    price: "R$ 35,00",
    category: "Utensílios",
    description: "Conjunto de panelas antiaderentes, pouco uso",
    location: "Casa & Lar - 1.8km",
    condition: "Muito Bom",
    seller: "Casa & Lar",
    isFree: false,
  },
  {
    id: 22,
    name: "Pratos e Copos",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop",
    price: "R$ 18,00",
    category: "Utensílios",
    description: "Conjunto completo de louças para 6 pessoas",
    location: "Dona Maria - 2km",
    condition: "Excelente",
    seller: "Dona Maria",
    isFree: false,
  },

  // Higiene
  {
    id: 23,
    name: "Kit Produtos de Limpeza",
    image: "https://images.unsplash.com/photo-1563453392212-326f5e854473?w=300&h=200&fit=crop",
    price: "Grátis",
    category: "Higiene",
    description: "Produtos de limpeza doados por empresa local",
    location: "ONG Esperança - 1km",
    condition: "Novo",
    seller: "ONG Esperança",
    isFree: true,
  },
  {
    id: 24,
    name: "Kit Higiene Pessoal",
    image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=300&h=200&fit=crop",
    price: "R$ 15,00",
    category: "Higiene",
    description: "Shampoo, sabonete, pasta de dente e outros itens",
    location: "Farmácia Popular - 1.5km",
    condition: "Novo",
    seller: "Farmácia Popular",
    isFree: false,
  },
]

interface CategoryScreenProps {
  category: string | null
  onProductSelect: (product: Product) => void
  onBack: () => void
}

export function CategoryScreen({ category, onProductSelect, onBack }: CategoryScreenProps) {
  if (!category) return null

  const categoryProducts = allProducts.filter((product) => product.category === category)

  const getCategoryIcon = (cat: string) => {
    const icons: { [key: string]: string } = {
      Alimentos: "🥬",
      Roupas: "👕",
      Móveis: "🪑",
      Eletrônicos: "📱",
      Livros: "📚",
      Brinquedos: "🧸",
      Utensílios: "🍴",
      Higiene: "🧴",
    }
    return icons[cat] || "📦"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white p-4 border-b sticky top-16 z-10">
        <div className="flex items-center gap-3 mb-3">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <span className="text-2xl">{getCategoryIcon(category)}</span>
            <h1 className="text-lg font-semibold">{category}</h1>
          </div>
        </div>
        <p className="text-gray-600 text-sm">{categoryProducts.length} produtos disponíveis</p>
      </div>

      {/* Products Grid */}
      <div className="p-4">
        <div className="grid grid-cols-2 gap-4">
          {categoryProducts.map((product) => (
            <Card
              key={product.id}
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => onProductSelect(product)}
            >
              <CardContent className="p-3">
                <div className="relative mb-3">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  {product.isFree && <Badge className="absolute top-2 right-2 bg-green-500 text-white">GRÁTIS</Badge>}
                  <Button variant="ghost" size="icon" className="absolute bottom-2 right-2 bg-white/80 hover:bg-white">
                    <Heart className="w-4 h-4" />
                  </Button>
                </div>

                <h3 className="font-medium text-sm mb-2 line-clamp-2">{product.name}</h3>

                <div className="flex items-center gap-1 mb-2">
                  <MapPin className="w-3 h-3 text-gray-400" />
                  <span className="text-xs text-gray-600">{product.location}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded">{product.condition}</span>
                  <span className="font-bold text-green-600">{product.price}</span>
                </div>

                <Button size="sm" className="w-full mt-2 bg-green-600 hover:bg-green-700">
                  {product.isFree ? "Solicitar" : "Comprar"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {categoryProducts.length === 0 && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📦</div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Nenhum produto encontrado</h3>
            <p className="text-gray-500">Não há produtos disponíveis nesta categoria no momento.</p>
          </div>
        )}
      </div>
    </div>
  )
}
