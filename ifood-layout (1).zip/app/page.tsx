"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { HomeScreen } from "@/components/screens/home-screen"
import { ProductsScreen } from "@/components/screens/products-screen"
import { ProductDetailScreen } from "@/components/screens/product-detail-screen"
import { CouponsScreen } from "@/components/screens/coupons-screen"
import { DeliveryScreen } from "@/components/screens/delivery-screen"
import { ProfileScreen } from "@/components/screens/profile-screen"
import { BottomNavigation } from "@/components/bottom-navigation"
import { CategoryScreen } from "@/components/screens/category-screen"

export type Screen = "home" | "products" | "product-detail" | "coupons" | "delivery" | "profile" | "category"

export interface Product {
  id: number
  name: string
  image: string
  price: string
  category: string
  description: string
  location: string
  condition: string
  seller: string
  isFree: boolean
}

export default function ReValorizeApp() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("home")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product)
    setCurrentScreen("product-detail")
  }

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category)
    setCurrentScreen("category")
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case "home":
        return (
          <HomeScreen
            onNavigate={setCurrentScreen}
            onProductSelect={handleProductSelect}
            onCategorySelect={handleCategorySelect}
          />
        )
      case "products":
        return <ProductsScreen onProductSelect={handleProductSelect} />
      case "product-detail":
        return <ProductDetailScreen product={selectedProduct} onNavigate={setCurrentScreen} />
      case "coupons":
        return <CouponsScreen />
      case "delivery":
        return <DeliveryScreen />
      case "profile":
        return <ProfileScreen />
      case "category":
        return (
          <CategoryScreen
            category={selectedCategory}
            onProductSelect={handleProductSelect}
            onBack={() => setCurrentScreen("home")}
          />
        )
      default:
        return (
          <HomeScreen
            onNavigate={setCurrentScreen}
            onProductSelect={handleProductSelect}
            onCategorySelect={handleCategorySelect}
          />
        )
    }
  }

  return (
    <div className="min-h-screen bg-green-50">
      <Header />
      <main className="pb-20">{renderScreen()}</main>
      <BottomNavigation currentScreen={currentScreen} onNavigate={setCurrentScreen} />
    </div>
  )
}
