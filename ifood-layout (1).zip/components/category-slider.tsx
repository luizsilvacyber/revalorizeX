"use client"

import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"

const categories = [
  { name: "Alimentos", icon: "🥬", color: "bg-green-100 text-green-700" },
  { name: "Roupas", icon: "👕", color: "bg-blue-100 text-blue-700" },
  { name: "Móveis", icon: "🪑", color: "bg-amber-100 text-amber-700" },
  { name: "Eletrônicos", icon: "📱", color: "bg-purple-100 text-purple-700" },
  { name: "Livros", icon: "📚", color: "bg-red-100 text-red-700" },
  { name: "Brinquedos", icon: "🧸", color: "bg-pink-100 text-pink-700" },
  { name: "Utensílios", icon: "🍴", color: "bg-orange-100 text-orange-700" },
  { name: "Higiene", icon: "🧴", color: "bg-cyan-100 text-cyan-700" },
]

interface CategorySliderProps {
  onCategorySelect?: (category: string) => void
}

export function CategorySlider({ onCategorySelect }: CategorySliderProps) {
  return (
    <section className="px-4 py-4">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Categorias</h2>
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex space-x-4 pb-4">
            {categories.map((category) => (
              <div
                key={category.name}
                className="flex flex-col items-center space-y-2 min-w-[80px] cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => onCategorySelect?.(category.name)}
              >
                <div className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl ${category.color}`}>
                  {category.icon}
                </div>
                <span className="text-xs font-medium text-gray-700 text-center">{category.name}</span>
              </div>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>
    </section>
  )
}
