"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Heart } from "lucide-react"
import type { Product } from "@/app/page"

const featuredProducts: Product[] = [
  {
    id: 1,
    name: "Cesta de Verduras Orgânicas",
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=300&h=200&fit=crop",
    price: "Grátis",
    category: "Alimentos",
    description: "Verduras frescas próximas do vencimento, perfeitas para consumo imediato",
    location: "Mercado Verde - 2km",
    condition: "Excelente",
    seller: "Mercado Verde",
    isFree: true,
  },
  {
    id: 5,
    name: "Jaqueta Jeans Feminina",
    image: "https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=300&h=200&fit=crop",
    price: "R$ 15,00",
    category: "Roupas",
    description: "Jaqueta jeans tamanho M, pouco usada, em ótimo estado",
    location: "Brechó Solidário - 1.5km",
    condition: "Muito Bom",
    seller: "Ana Silva",
    isFree: false,
  },
  {
    id: 9,
    name: "Mesa de Jantar 4 Lugares",
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&h=200&fit=crop",
    price: "R$ 80,00",
    category: "Móveis",
    description: "Mesa de madeira com 4 cadeiras, pequenos riscos mas estrutura sólida",
    location: "Família Santos - 3km",
    condition: "Bom",
    seller: "João Santos",
    isFree: false,
  },
  {
    id: 13,
    name: "Smartphone Samsung J5",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=200&fit=crop",
    price: "R$ 120,00",
    category: "Eletrônicos",
    description: "Celular funcionando perfeitamente, apenas tela com pequenos riscos",
    location: "TechReuso - 2.5km",
    condition: "Bom",
    seller: "TechReuso",
    isFree: false,
  },
  {
    id: 23,
    name: "Kit Produtos de Limpeza",
    image: "https://images.unsplash.com/photo-1563453392212-326f5e854473?w=300&h=200&fit=crop",
    price: "Grátis",
    category: "Higiene",
    description: "Produtos de limpeza doados por empresa local",
    location: "ONG Esperança - 1km",
    condition: "Novo",
    seller: "ONG Esperança",
    isFree: true,
  },
  {
    id: 17,
    name: "Livros Infantis Variados",
    image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=200&fit=crop",
    price: "R$ 5,00",
    category: "Livros",
    description: "Coleção de 10 livros infantis em bom estado",
    location: "Biblioteca Comunitária - 1.8km",
    condition: "Bom",
    seller: "Biblioteca Comunitária",
    isFree: false,
  },
]

interface FeaturedProductsProps {
  onProductSelect: (product: Product) => void
}

export function FeaturedProducts({ onProductSelect }: FeaturedProductsProps) {
  return (
    <section className="px-4 py-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Produtos em Destaque</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {featuredProducts.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
                {product.isFree && (
                  <Badge className="absolute top-2 left-2 bg-green-500 hover:bg-green-600">GRÁTIS</Badge>
                )}
                <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-white/80 hover:bg-white">
                  <Heart className="w-4 h-4" />
                </Button>
              </div>

              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-900 text-lg">{product.name}</h3>
                  <span className="text-lg font-bold text-green-600">{product.price}</span>
                </div>

                <p className="text-gray-600 text-sm mb-2">{product.category}</p>
                <p className="text-gray-700 text-sm mb-3 line-clamp-2">{product.description}</p>

                <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>{product.location}</span>
                  </div>
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded">{product.condition}</span>
                </div>

                <Button onClick={() => onProductSelect(product)} className="w-full bg-green-600 hover:bg-green-700">
                  {product.isFree ? "Solicitar" : "Comprar"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
