import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Clock, Truck } from "lucide-react"

const restaurants = [
  {
    id: 1,
    name: "McDonald's",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.5,
    deliveryTime: "25-35 min",
    deliveryFee: "R$ 3,99",
    category: "Lanches",
    promotion: "Entrega grátis",
  },
  {
    id: 2,
    name: "Burger King",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.3,
    deliveryTime: "30-40 min",
    deliveryFee: "R$ 4,99",
    category: "Lanches",
    promotion: null,
  },
  {
    id: 3,
    name: "Pizza Hut",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.7,
    deliveryTime: "35-45 min",
    deliveryFee: "R$ 5,99",
    category: "Pizza",
    promotion: "20% OFF",
  },
  {
    id: 4,
    name: "Subway",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.4,
    deliveryTime: "20-30 min",
    deliveryFee: "R$ 2,99",
    category: "Sanduíches",
    promotion: null,
  },
  {
    id: 5,
    name: "KFC",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.2,
    deliveryTime: "25-35 min",
    deliveryFee: "R$ 4,99",
    category: "Frango",
    promotion: "Entrega grátis",
  },
  {
    id: 6,
    name: "Domino's Pizza",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.6,
    deliveryTime: "30-40 min",
    deliveryFee: "R$ 3,99",
    category: "Pizza",
    promotion: "15% OFF",
  },
]

export function RestaurantGrid() {
  return (
    <section className="px-4 py-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Restaurantes</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {restaurants.map((restaurant) => (
            <Card key={restaurant.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
              <div className="relative">
                <img
                  src={restaurant.image || "/placeholder.svg"}
                  alt={restaurant.name}
                  className="w-full h-48 object-cover"
                />
                {restaurant.promotion && (
                  <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">{restaurant.promotion}</Badge>
                )}
              </div>

              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-900 text-lg">{restaurant.name}</h3>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{restaurant.rating}</span>
                  </div>
                </div>

                <p className="text-gray-600 text-sm mb-3">{restaurant.category}</p>

                <div className="flex items-center justify-between text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{restaurant.deliveryTime}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Truck className="w-4 h-4" />
                    <span>{restaurant.deliveryFee}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
