"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CategorySlider } from "@/components/category-slider"
import { FeaturedProducts } from "@/components/featured-products"
import { ImpactStats } from "@/components/impact-stats"
import { Recycle, Heart, Users } from "lucide-react"
import type { Screen, Product } from "@/app/page"

interface HomeScreenProps {
  onNavigate: (screen: Screen) => void
  onProductSelect: (product: Product) => void
  onCategorySelect: (category: string) => void
}

export function HomeScreen({ onNavigate, onProductSelect, onCategorySelect }: HomeScreenProps) {
  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <section className="px-4 py-6">
        <div className="max-w-7xl mx-auto">
          <Card className="bg-gradient-to-r from-green-600 to-green-700 text-white p-6 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold mb-2">Bem-vindo ao ReValorize!</h2>
                <p className="text-green-100 mb-4">Transforme o que não usa em oportunidade para quem precisa</p>
                <Button onClick={() => onNavigate("coupons")} className="bg-white text-green-700 hover:bg-green-50">
                  Ver Meus Cupons
                </Button>
              </div>
              <div className="text-4xl">🌱</div>
            </div>
          </Card>
        </div>
      </section>

      {/* Impact Stats */}
      <ImpactStats />

      {/* Categories */}
      <CategorySlider onCategorySelect={onCategorySelect} />

      {/* Mission Cards */}
      <section className="px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Nossa Missão</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4 bg-green-50 border-green-200">
              <div className="flex items-center space-x-3 mb-2">
                <Recycle className="w-6 h-6 text-green-600" />
                <h3 className="font-semibold text-green-800">Sustentabilidade</h3>
              </div>
              <p className="text-sm text-green-700">Reduzimos o desperdício dando nova vida aos produtos</p>
            </Card>

            <Card className="p-4 bg-amber-50 border-amber-200">
              <div className="flex items-center space-x-3 mb-2">
                <Heart className="w-6 h-6 text-amber-600" />
                <h3 className="font-semibold text-amber-800">Solidariedade</h3>
              </div>
              <p className="text-sm text-amber-700">Conectamos quem pode doar com quem precisa</p>
            </Card>

            <Card className="p-4 bg-blue-50 border-blue-200">
              <div className="flex items-center space-x-3 mb-2">
                <Users className="w-6 h-6 text-blue-600" />
                <h3 className="font-semibold text-blue-800">Inclusão</h3>
              </div>
              <p className="text-sm text-blue-700">Promovemos acesso igualitário a produtos essenciais</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <FeaturedProducts onProductSelect={onProductSelect} />
    </div>
  )
}
