"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, MapPin, User, Star, Heart, Share2 } from "lucide-react"
import type { Product, Screen } from "@/app/page"

interface ProductDetailScreenProps {
  product: Product | null
  onNavigate: (screen: Screen) => void
}

export function ProductDetailScreen({ product, onNavigate }: ProductDetailScreenProps) {
  if (!product) return null

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white sticky top-16 z-40 border-b">
        <Button variant="ghost" size="icon" onClick={() => onNavigate("products")}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex space-x-2">
          <Button variant="ghost" size="icon">
            <Heart className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Share2 className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Product Image */}
      <div className="relative">
        <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full h-80 object-cover" />
        {product.isFree && (
          <Badge className="absolute top-4 left-4 bg-green-500 hover:bg-green-600 text-lg px-3 py-1">GRÁTIS</Badge>
        )}
      </div>

      {/* Product Info */}
      <div className="p-4 space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{product.name}</h1>
            <p className="text-green-600 font-medium">{product.category}</p>
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold text-green-600">{product.price}</span>
          </div>
        </div>

        <p className="text-gray-700">{product.description}</p>

        {/* Seller Info */}
        <Card className="bg-gray-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">{product.seller}</h3>
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm">4.8 (127 avaliações)</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Location and Condition */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">Localização</p>
                  <p className="text-sm text-gray-600">{product.location}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div>
                <p className="font-medium">Condição</p>
                <p className="text-sm text-gray-600">{product.condition}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-4">
          <Button
            onClick={() => onNavigate("delivery")}
            className="w-full bg-green-600 hover:bg-green-700 h-12 text-lg"
          >
            {product.isFree ? "Solicitar Produto" : "Comprar Agora"}
          </Button>

          <Button variant="outline" className="w-full h-12">
            Conversar com Vendedor
          </Button>
        </div>
      </div>
    </div>
  )
}
