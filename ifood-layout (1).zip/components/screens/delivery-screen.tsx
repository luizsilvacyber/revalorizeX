"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { MapPin, Truck, Ticket, Clock } from "lucide-react"

export function DeliveryScreen() {
  const [selectedCoupon, setSelectedCoupon] = useState<string | null>(null)

  const availableCoupons = [
    { id: "1", title: "Entrega Grátis", value: "R$ 8,00", description: "Válido para este pedido" },
    { id: "2", title: "Desconto 20%", value: "20%", description: "Máximo R$ 15,00" },
  ]

  return (
    <div className="p-4 space-y-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Finalizar Pedido</h1>
          <p className="text-gray-600">Confirme seu endereço e forma de entrega</p>
        </div>

        {/* Delivery Address */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-green-600" />
              <span>Endereço de Entrega</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="street">Rua</Label>
                <Input id="street" placeholder="Nome da rua" />
              </div>
              <div>
                <Label htmlFor="number">Número</Label>
                <Input id="number" placeholder="123" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="neighborhood">Bairro</Label>
                <Input id="neighborhood" placeholder="Nome do bairro" />
              </div>
              <div>
                <Label htmlFor="city">Cidade</Label>
                <Input id="city" placeholder="Sua cidade" />
              </div>
            </div>
            <div>
              <Label htmlFor="reference">Ponto de Referência (opcional)</Label>
              <Input id="reference" placeholder="Ex: Próximo ao mercado" />
            </div>
          </CardContent>
        </Card>

        {/* Delivery Options */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Truck className="w-5 h-5 text-green-600" />
              <span>Opções de Entrega</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="border rounded-lg p-4 cursor-pointer hover:bg-green-50 border-green-200 bg-green-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-green-800">Entrega Solidária</h3>
                  <p className="text-sm text-green-600">Entrega gratuita com cupom social</p>
                  <div className="flex items-center space-x-1 mt-1">
                    <Clock className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-600">2-3 dias úteis</span>
                  </div>
                </div>
                <Badge className="bg-green-600">Recomendado</Badge>
              </div>
            </div>

            <div className="border rounded-lg p-4 cursor-pointer hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">Entrega Expressa</h3>
                  <p className="text-sm text-gray-600">Entrega no mesmo dia</p>
                  <div className="flex items-center space-x-1 mt-1">
                    <Clock className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-600">Até 6 horas</span>
                  </div>
                </div>
                <span className="font-semibold">R$ 12,00</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Available Coupons */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Ticket className="w-5 h-5 text-green-600" />
              <span>Usar Cupom</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {availableCoupons.map((coupon) => (
              <div
                key={coupon.id}
                className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                  selectedCoupon === coupon.id ? "border-green-500 bg-green-50" : "border-gray-200 hover:bg-gray-50"
                }`}
                onClick={() => setSelectedCoupon(coupon.id)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold">{coupon.title}</h3>
                    <p className="text-sm text-gray-600">{coupon.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">{coupon.value}</p>
                    {selectedCoupon === coupon.id && <Badge className="bg-green-600 mt-1">Selecionado</Badge>}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Order Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Resumo do Pedido</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>R$ 25,00</span>
            </div>
            <div className="flex justify-between">
              <span>Taxa de entrega</span>
              <span className={selectedCoupon === "1" ? "line-through text-gray-400" : ""}>R$ 8,00</span>
            </div>
            {selectedCoupon === "1" && (
              <div className="flex justify-between text-green-600">
                <span>Desconto (Entrega Grátis)</span>
                <span>-R$ 8,00</span>
              </div>
            )}
            <hr />
            <div className="flex justify-between font-bold text-lg">
              <span>Total</span>
              <span className="text-green-600">{selectedCoupon === "1" ? "R$ 25,00" : "R$ 33,00"}</span>
            </div>
          </CardContent>
        </Card>

        {/* Confirm Button */}
        <Button className="w-full bg-green-600 hover:bg-green-700 h-12 text-lg">Confirmar Pedido</Button>
      </div>
    </div>
  )
}
